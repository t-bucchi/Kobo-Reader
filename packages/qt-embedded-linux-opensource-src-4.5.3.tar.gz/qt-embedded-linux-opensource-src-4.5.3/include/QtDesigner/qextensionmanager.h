#include "../../tools/designer/src/lib/extension/qextensionmanager.h"
