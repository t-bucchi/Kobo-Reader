#include "../../tools/designer/src/lib/sdk/abstractbrushmanager.h"
