#include "../../tools/designer/src/lib/sdk/abstractpromotioninterface.h"
