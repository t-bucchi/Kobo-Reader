#include "../../tools/designer/src/lib/sdk/abstractwidgetfactory.h"
