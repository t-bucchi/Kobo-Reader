#include "../../tools/designer/src/lib/sdk/abstractintegration.h"
