#include "../../tools/designer/src/lib/sdk/abstractresourcebrowser.h"
