#include "../../tools/designer/src/lib/components/qdesigner_components_global.h"
