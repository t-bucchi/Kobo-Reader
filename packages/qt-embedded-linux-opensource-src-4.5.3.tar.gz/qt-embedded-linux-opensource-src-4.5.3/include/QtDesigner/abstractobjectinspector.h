#include "../../tools/designer/src/lib/sdk/abstractobjectinspector.h"
