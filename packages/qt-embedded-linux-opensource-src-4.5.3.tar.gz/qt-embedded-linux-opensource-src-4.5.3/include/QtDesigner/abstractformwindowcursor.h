#include "../../tools/designer/src/lib/sdk/abstractformwindowcursor.h"
