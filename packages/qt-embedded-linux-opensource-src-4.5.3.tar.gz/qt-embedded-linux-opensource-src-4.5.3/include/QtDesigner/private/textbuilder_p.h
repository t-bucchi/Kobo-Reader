#include "../../../tools/designer/src/lib/uilib/textbuilder_p.h"
