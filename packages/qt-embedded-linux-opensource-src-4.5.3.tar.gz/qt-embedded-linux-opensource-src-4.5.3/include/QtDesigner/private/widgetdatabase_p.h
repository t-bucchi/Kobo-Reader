#include "../../../tools/designer/src/lib/shared/widgetdatabase_p.h"
