#include "../../../tools/designer/src/lib/shared/previewmanager_p.h"
