#include "../../../tools/designer/src/lib/shared/qdesigner_integration_p.h"
