#include "../../../tools/designer/src/lib/shared/qdesigner_propertycommand_p.h"
