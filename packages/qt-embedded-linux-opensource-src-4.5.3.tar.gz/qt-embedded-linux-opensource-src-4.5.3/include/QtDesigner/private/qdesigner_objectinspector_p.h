#include "../../../tools/designer/src/lib/shared/qdesigner_objectinspector_p.h"
