#include "../../../tools/designer/src/lib/shared/qdesigner_dockwidget_p.h"
