#include "../../../tools/designer/src/lib/shared/iconloader_p.h"
