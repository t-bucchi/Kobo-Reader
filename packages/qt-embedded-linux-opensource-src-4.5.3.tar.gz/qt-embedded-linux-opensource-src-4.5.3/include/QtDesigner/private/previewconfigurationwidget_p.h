#include "../../../tools/designer/src/lib/shared/previewconfigurationwidget_p.h"
