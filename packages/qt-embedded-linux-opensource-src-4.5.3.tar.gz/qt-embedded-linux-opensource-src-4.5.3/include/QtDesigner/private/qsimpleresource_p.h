#include "../../../tools/designer/src/lib/shared/qsimpleresource_p.h"
