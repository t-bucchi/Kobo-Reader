#include "../../../tools/designer/src/lib/shared/qtresourceview_p.h"
