#include "../../../tools/designer/src/lib/shared/dialoggui_p.h"
