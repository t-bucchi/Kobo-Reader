#include "../../../tools/designer/src/lib/shared/zoomwidget_p.h"
