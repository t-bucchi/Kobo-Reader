#include "../../../tools/designer/src/lib/shared/plaintexteditor_p.h"
