#include "../../../tools/designer/src/lib/shared/qtresourcemodel_p.h"
