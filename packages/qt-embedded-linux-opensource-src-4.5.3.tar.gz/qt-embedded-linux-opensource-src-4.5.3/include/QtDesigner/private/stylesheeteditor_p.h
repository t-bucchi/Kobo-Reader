#include "../../../tools/designer/src/lib/shared/stylesheeteditor_p.h"
