#include "../../../tools/designer/src/lib/shared/signalslotdialog_p.h"
