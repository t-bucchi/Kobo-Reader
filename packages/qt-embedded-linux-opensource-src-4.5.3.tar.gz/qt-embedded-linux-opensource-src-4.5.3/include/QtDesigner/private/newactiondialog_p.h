#include "../../../tools/designer/src/lib/shared/newactiondialog_p.h"
