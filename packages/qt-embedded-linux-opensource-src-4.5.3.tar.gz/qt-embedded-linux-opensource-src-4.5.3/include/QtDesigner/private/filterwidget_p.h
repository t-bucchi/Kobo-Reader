#include "../../../tools/designer/src/lib/shared/filterwidget_p.h"
