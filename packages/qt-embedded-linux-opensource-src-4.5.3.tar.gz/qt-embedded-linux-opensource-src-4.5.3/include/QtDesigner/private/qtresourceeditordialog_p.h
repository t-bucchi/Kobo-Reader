#include "../../../tools/designer/src/lib/shared/qtresourceeditordialog_p.h"
