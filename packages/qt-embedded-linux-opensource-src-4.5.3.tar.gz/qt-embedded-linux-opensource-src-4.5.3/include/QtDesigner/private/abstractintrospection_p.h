#include "../../../tools/designer/src/lib/sdk/abstractintrospection_p.h"
