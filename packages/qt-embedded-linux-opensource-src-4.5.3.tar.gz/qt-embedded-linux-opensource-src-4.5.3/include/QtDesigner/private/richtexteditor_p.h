#include "../../../tools/designer/src/lib/shared/richtexteditor_p.h"
