#include "../../../tools/designer/src/lib/shared/promotionmodel_p.h"
