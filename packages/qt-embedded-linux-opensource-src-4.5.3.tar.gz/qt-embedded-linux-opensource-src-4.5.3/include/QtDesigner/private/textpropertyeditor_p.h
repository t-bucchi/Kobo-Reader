#include "../../../tools/designer/src/lib/shared/textpropertyeditor_p.h"
