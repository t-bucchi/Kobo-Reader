#include "../../../tools/designer/src/lib/shared/qdesigner_qsettings_p.h"
