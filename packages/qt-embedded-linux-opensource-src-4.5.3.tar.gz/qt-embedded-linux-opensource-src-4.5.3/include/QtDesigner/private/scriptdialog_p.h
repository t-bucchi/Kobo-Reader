#include "../../../tools/designer/src/lib/shared/scriptdialog_p.h"
