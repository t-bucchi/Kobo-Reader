#include "../../../tools/designer/src/lib/shared/qdesigner_tabwidget_p.h"
