#include "../../../tools/designer/src/lib/shared/shared_settings_p.h"
