#include "../../../tools/designer/src/lib/shared/qdesigner_introspection_p.h"
