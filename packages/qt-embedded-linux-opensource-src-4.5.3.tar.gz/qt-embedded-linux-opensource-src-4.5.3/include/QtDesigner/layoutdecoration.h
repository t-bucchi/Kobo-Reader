#include "../../tools/designer/src/lib/sdk/layoutdecoration.h"
