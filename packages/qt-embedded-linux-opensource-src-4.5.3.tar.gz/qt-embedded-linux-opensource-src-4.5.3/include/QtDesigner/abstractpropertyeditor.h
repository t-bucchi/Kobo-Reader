#include "../../tools/designer/src/lib/sdk/abstractpropertyeditor.h"
