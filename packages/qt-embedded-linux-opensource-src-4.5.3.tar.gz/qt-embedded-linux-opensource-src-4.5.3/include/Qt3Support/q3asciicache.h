#include "../../src/qt3support/tools/q3asciicache.h"
