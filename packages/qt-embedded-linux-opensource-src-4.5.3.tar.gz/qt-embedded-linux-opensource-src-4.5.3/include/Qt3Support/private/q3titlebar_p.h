#include "../../../src/qt3support/widgets/q3titlebar_p.h"
