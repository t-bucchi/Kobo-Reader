#include "../../../src/qt3support/text/q3richtext_p.h"
