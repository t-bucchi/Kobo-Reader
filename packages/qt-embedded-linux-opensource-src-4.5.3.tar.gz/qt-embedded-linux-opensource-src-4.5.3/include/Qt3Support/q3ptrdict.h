#include "../../src/qt3support/tools/q3ptrdict.h"
