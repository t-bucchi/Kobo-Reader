#include "../../src/qt3support/tools/q3gdict.h"
