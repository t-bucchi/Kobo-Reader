#include "../../src/qt3support/widgets/q3whatsthis.h"
