#include "../../src/qt3support/tools/q3intcache.h"
