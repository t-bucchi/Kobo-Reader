#include "../../src/qt3support/other/qiconset.h"
