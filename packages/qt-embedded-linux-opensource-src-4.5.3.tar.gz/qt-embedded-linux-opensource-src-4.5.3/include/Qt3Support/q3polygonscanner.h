#include "../../src/qt3support/other/q3polygonscanner.h"
