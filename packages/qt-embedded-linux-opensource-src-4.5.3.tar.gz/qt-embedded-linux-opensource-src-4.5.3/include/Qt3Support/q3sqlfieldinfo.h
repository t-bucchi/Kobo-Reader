#include "../../src/qt3support/sql/q3sqlfieldinfo.h"
