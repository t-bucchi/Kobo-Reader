#include "../../src/qt3support/other/q3accel.h"
