#include "../../src/qt3support/text/q3textedit.h"
