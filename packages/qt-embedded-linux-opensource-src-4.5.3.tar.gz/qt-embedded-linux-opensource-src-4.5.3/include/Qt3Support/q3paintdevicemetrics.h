#include "../../src/qt3support/painting/q3paintdevicemetrics.h"
