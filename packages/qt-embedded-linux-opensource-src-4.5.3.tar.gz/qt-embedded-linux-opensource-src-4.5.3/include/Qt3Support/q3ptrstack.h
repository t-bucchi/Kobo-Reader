#include "../../src/qt3support/tools/q3ptrstack.h"
