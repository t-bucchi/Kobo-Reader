#include "../../src/qt3support/tools/q3memarray.h"
