#include "../../src/qt3support/tools/q3intdict.h"
