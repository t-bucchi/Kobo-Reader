#include "../../src/qt3support/painting/q3pointarray.h"
