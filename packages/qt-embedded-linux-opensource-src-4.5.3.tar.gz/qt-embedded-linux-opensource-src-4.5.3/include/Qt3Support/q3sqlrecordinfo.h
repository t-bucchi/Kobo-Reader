#include "../../src/qt3support/sql/q3sqlrecordinfo.h"
