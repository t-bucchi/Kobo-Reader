#include "../../src/phonon/../3rdparty/phonon/phonon/effectwidget.h"
