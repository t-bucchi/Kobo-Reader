#include "../../../src/phonon/../3rdparty/phonon/phonon/effectparameter_p.h"
