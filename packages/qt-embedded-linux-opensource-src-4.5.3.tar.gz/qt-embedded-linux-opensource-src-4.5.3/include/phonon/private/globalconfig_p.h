#include "../../../src/phonon/../3rdparty/phonon/phonon/globalconfig_p.h"
