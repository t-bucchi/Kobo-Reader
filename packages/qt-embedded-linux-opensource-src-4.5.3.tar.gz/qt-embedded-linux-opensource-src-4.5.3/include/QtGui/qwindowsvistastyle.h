#include "../../src/gui/styles/qwindowsvistastyle.h"
