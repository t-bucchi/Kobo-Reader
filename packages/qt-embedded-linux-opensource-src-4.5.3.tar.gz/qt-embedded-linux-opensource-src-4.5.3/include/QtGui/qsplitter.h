#include "../../src/gui/widgets/qsplitter.h"
