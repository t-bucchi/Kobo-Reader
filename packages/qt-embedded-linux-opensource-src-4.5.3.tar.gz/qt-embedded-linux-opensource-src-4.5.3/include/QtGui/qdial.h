#include "../../src/gui/widgets/qdial.h"
