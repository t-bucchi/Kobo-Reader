#include "../../src/gui/styles/qstyleplugin.h"
