#include "../../src/gui/styles/qgtkstyle.h"
