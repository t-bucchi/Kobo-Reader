#include "../../src/gui/widgets/qtextbrowser.h"
