#include "../../src/gui/styles/qmotifstyle.h"
