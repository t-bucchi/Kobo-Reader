#include "../../src/gui/styles/qcleanlooksstyle.h"
