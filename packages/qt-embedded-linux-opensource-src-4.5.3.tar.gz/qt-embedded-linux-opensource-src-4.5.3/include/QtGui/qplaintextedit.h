#include "../../src/gui/widgets/qplaintextedit.h"
