#include "../../src/gui/styles/qwindowsmobilestyle.h"
