#include "../../src/gui/widgets/qlabel.h"
