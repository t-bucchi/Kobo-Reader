#include "../../src/gui/widgets/qlcdnumber.h"
