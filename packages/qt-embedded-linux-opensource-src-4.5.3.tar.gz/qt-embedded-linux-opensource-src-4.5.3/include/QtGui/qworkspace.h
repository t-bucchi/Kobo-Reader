#include "../../src/gui/widgets/qworkspace.h"
