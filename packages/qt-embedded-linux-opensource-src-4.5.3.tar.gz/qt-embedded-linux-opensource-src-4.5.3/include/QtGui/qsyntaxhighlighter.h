#include "../../src/gui/text/qsyntaxhighlighter.h"
