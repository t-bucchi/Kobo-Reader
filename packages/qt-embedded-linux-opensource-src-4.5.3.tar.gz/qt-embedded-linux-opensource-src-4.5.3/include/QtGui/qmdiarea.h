#include "../../src/gui/widgets/qmdiarea.h"
