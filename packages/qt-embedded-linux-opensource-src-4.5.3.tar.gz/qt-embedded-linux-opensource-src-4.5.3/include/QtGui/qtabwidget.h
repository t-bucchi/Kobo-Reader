#include "../../src/gui/widgets/qtabwidget.h"
