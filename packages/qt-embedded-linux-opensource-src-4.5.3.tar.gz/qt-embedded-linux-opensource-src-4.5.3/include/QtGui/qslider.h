#include "../../src/gui/widgets/qslider.h"
