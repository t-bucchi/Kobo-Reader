#include "../../src/gui/widgets/qstackedwidget.h"
