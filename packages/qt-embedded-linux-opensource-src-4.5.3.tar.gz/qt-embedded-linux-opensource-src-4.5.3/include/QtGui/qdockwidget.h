#include "../../src/gui/widgets/qdockwidget.h"
