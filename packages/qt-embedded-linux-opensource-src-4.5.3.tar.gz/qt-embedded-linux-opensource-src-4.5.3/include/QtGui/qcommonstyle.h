#include "../../src/gui/styles/qcommonstyle.h"
