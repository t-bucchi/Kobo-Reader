#include "../../src/gui/widgets/qsplashscreen.h"
