#include "../../src/gui/widgets/qtextedit.h"
