#include "../../src/gui/styles/qcdestyle.h"
