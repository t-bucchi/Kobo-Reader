#include "../../../src/scripttools/debugging/qscriptdebuggerstackwidgetinterface_p.h"
