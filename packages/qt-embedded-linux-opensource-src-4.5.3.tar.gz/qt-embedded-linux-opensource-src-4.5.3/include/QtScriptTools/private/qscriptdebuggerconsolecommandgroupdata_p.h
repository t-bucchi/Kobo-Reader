#include "../../../src/scripttools/debugging/qscriptdebuggerconsolecommandgroupdata_p.h"
