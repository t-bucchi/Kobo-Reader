#include "../../../src/scripttools/debugging/qscriptdebuggerstackwidget_p.h"
