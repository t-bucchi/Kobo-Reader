#include "../../../src/scripttools/debugging/qscriptdebuggerscriptedconsolecommand_p.h"
