#include "../../../src/scripttools/debugging/qscriptdebugoutputwidgetinterface_p_p.h"
