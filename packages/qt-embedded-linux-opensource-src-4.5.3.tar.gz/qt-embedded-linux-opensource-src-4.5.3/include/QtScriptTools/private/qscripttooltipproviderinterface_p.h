#include "../../../src/scripttools/debugging/qscripttooltipproviderinterface_p.h"
