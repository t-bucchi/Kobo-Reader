#include "../../../src/scripttools/debugging/qscriptdebuggerscriptsmodel_p.h"
