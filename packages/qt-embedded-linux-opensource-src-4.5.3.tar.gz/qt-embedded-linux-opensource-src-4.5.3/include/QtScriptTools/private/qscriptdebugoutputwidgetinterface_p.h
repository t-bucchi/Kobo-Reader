#include "../../../src/scripttools/debugging/qscriptdebugoutputwidgetinterface_p.h"
