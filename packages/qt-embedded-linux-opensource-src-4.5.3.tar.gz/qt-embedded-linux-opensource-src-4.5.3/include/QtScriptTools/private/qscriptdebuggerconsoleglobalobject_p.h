#include "../../../src/scripttools/debugging/qscriptdebuggerconsoleglobalobject_p.h"
