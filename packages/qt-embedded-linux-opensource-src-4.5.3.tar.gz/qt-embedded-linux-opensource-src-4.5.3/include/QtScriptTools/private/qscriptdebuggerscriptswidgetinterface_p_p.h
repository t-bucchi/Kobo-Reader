#include "../../../src/scripttools/debugging/qscriptdebuggerscriptswidgetinterface_p_p.h"
