#include "../../../src/scripttools/debugging/qscriptdebuggerconsolewidget_p.h"
