#include "../../../src/scripttools/debugging/qscriptdebuggereventhandlerinterface_p.h"
