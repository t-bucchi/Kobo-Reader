#include "../../../src/scripttools/debugging/qscriptdebuggerconsole_p.h"
