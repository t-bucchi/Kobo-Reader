#include "../../../src/scripttools/debugging/qscriptdebuggercodefinderwidgetinterface_p.h"
