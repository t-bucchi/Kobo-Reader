#include "../../../src/scripttools/debugging/qscriptdebuggerwidgetfactoryinterface_p.h"
