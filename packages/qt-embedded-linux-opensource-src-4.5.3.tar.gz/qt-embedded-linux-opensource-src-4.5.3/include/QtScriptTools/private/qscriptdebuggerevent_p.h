#include "../../../src/scripttools/debugging/qscriptdebuggerevent_p.h"
