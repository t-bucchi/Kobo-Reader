#include "../../../src/scripttools/debugging/qscriptdebuggerconsolecommandmanager_p.h"
