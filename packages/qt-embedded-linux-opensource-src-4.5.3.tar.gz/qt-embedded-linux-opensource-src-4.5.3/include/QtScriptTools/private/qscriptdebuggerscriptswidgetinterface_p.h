#include "../../../src/scripttools/debugging/qscriptdebuggerscriptswidgetinterface_p.h"
