#include "../../../src/scripttools/debugging/qscriptdebuggercodefinderwidget_p.h"
