#include "../../../src/scripttools/debugging/qscriptdebuggerconsolecommand_p_p.h"
