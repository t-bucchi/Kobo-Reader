#include "../../../src/scripttools/debugging/qscriptdebuggerlocalsmodel_p.h"
