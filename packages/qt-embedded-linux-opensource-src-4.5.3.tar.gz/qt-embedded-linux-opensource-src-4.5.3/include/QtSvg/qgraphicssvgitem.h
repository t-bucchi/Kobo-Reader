#include "../../src/svg/qgraphicssvgitem.h"
