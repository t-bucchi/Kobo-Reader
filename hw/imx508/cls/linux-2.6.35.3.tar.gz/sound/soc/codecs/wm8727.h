/*
 * wm8727.h
 *
 *  Created on: 15-Oct-2009
 *      Author: neil.jones@imgtec.com
 *
 * Copyright (C) 2009 Imagination Technologies Ltd.
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  either version 2 of the  License, or (at your
 *  option) any later version.
 */

#ifndef WM8727_H_
#define WM8727_H_

extern struct snd_soc_dai wm8727_dai;
extern struct snd_soc_codec_device soc_codec_dev_wm8727;

#endif /* WM8727_H_ */
